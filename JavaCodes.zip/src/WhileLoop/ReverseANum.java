package WhileLoop;

import java.util.Scanner;

public class ReverseANum {
	int num;
	int revnum;
	void reverseNum(int num) {
		this.num=num;
		int rem;
		while(num>0) {
			rem=num%10;
			revnum=(revnum*10)+rem;
			num/=10;
			
		}
		 display(revnum);
	}
	void display(int num) {
		System.out.println(num);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		ReverseANum o1=new ReverseANum();
       
        if(num>0) {
        	 o1.reverseNum(num);
        }else {
        	num=Math.abs(num);
        	o1.reverseNum(num);
        }

//		System.out.println(result);
	}

}
