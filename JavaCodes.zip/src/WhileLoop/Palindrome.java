package WhileLoop;

import java.util.Scanner;

public class Palindrome {
	int num;
	int orinum;
	
	Palindrome(int num) {
		this.num=num;
		int rem;
		int revnum=0;
		  orinum=num;
	
	
		while(num>0) {
			rem=num%10;
		revnum=(revnum*10)+rem;
			num/=10;
			
		}
		toDisplay( revnum);
		
	}
	void toDisplay(int revnum) {
		if(revnum==orinum) {
              System.out.println("Palindrome");
   		}else {
			System.out.println("not A Palindrome"+revnum);
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		new Palindrome(num);
		
	}

}
