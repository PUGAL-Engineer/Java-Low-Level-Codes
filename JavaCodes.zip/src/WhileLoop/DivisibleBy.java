package WhileLoop;

import java.util.Scanner;

public class DivisibleBy {
	int num;
 
	
	DivisibleBy(int num){
		this.num=num;
	int count=0;
		while(count<5&&this.num<1000) {
			if(num%2==0 && num%3==0&&num%5==0) {
				System.out.print(num+" ");
				count++;
				}
			num++;
//			System.out.print(num+" \n"+count);
			
			
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int data=sc.nextInt();
		new DivisibleBy(data);
	}

}
