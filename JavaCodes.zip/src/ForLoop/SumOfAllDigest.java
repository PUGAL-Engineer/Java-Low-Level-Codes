package ForLoop;

import java.util.Scanner;

public class SumOfAllDigest {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the num ");
		int num=sc.nextInt();
		int rem,sum=0;
		for(int i=num;i>0;) {
			rem=i%10;
			sum+=rem;
			i/=10;
			
			
		}
		System.out.println(sum);
	}

}
