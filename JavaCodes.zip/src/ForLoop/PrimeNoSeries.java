package ForLoop;

public class PrimeNoSeries {
	public static void main(String[] args) {
		
		for(int i=0;i<=100;i++) {
			boolean prime=true;
			if(i>10&&i<100) {
				for(int j=2;j<=i/2;j++) {
					if(i%j==0) {
					prime=false;
					}
				}
				if(prime) {
					System.out.print(i+" ");
				}
			}
		}
	}

}
