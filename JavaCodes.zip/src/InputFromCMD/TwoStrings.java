package InputFromCMD;

public class TwoStrings {

	public static void main(String[] args) {
		if(args.length!=2) {
			System.out.println("Enter Two Arguments");
		}
		String company=args[0];
		String location=args[1];
		
		System.out.println(company+" Technologies "+location);

	}

}
