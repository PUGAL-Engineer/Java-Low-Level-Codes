package InputFromCMD;

public class StringInput {
	public static void main(String[] a) {
		if(a.length!=1) {
			System.out.println("Invalid");
		}
		String name=a[0];
		
		System.out.println("Welcome "+name);
	}

}
