package Arrays;

import java.util.Scanner;

public class ArraySort {

static	void toSetArr(int[] arr,int size) {
		Scanner sc=new Scanner(System.in);
		for(int i =0;i<size;i++) {
			System.out.println("Enter The Element:");
			arr[i]=sc.nextInt();
		}
	}
static	void toSort(int [] arr,int size) {
		for(int i=0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				if(arr[i]>arr[j]) {
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
				
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter The No Of Element");
	 int size=sc.nextInt();
	int[] arr=new int[size];
		toSetArr(arr,size);
		toSort(arr,size);
for(int i =0;i<size;i++) {
			System.out.print(arr[i]+" ");	
		}
	}
}
