package Arrays;

import java.util.Scanner;

public class MinAndMax {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		System.out.print("Enter the Size of an Array : ");
		int size=sc.nextInt();
		int[] arr=new int[size];
		for(int i=0;i<size;i++) {
			System.out.print("Enter the Element of an Array : ");
			arr[i]=sc.nextInt();
		}
		int minimum=arr[0],max=arr[0];
		for(int i=0;i<size;i++) {
			if(arr[i]<minimum) {
				minimum=arr[i];
			}
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println("The Minimum is: "+minimum+"\nThe Maximum is: "+max);
		sc.close();
	}

}
