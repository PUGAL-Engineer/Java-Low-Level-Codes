package Arrays;

public class AsciiToChar {

	public static void main(String[] args) {
		        int[] asciiValues = {65, 66, 67, 68, 69};
		        System.out.println("Characters from ASCII values:");
		        for (int i = 0; i < asciiValues.length; i++) {
		            System.out.print((char) asciiValues[i] + " ");
		        }
		    }
		}


	


