package Arrays;

import java.util.Scanner;

public class NumPresent {
	static int toCheck(int[] array,int num) {
		for(int i=0;i<array.length;i++) {
			if(num==array[i]) {
				return i;
			}
		
		}return -1;
	}
	public static void main(String[] args) {
		
	
		Scanner sc=new Scanner(System.in);
     	System.out.println("Enter the Size of an Array : ");
		int size=sc.nextInt();
		int[] arr=new int[size];
		for(int i=0;i<size;i++) {
			System.out.print("Enter the Element of an Array : ");
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the element to find in an Array : ");
		int num=sc.nextInt();
		int present =toCheck(arr,num);
		
		System.out.println(present);
		sc.close();
	}

}
