package Arrays;

import java.security.DrbgParameters.NextBytes;
import java.util.Scanner;

public class SumAndAvg {
	

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sum=0;
		double avg=0;
		System.out.print("Enter the Size of an Array : ");
		int size=sc.nextInt();
		int[] arr=new int[size];
		for(int i=0;i<size;i++) {
			System.out.print("Enter the Element of an Array : ");
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<size;i++) {
			sum=sum+arr[i];
			
		}
		avg=sum/size;
		System.out.println("The Sum Of Array element is: "+sum+"\nThe average is: "+avg);
	}

}
