package IfStatement;

import java.util.Scanner;
class Number{
	 Number(int num) {
		if(num>0) {
			System.out.println("Positive Number");
			
		}else if(num<0) {
			System.out.println("Negative Number");
		}else {
			System.out.println("Zero");
		}
	}
}

public class PosNega {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter The Number: ");
		int num=sc.nextInt();
		 sc.close();
		new Number(num);
	   

	}

}
