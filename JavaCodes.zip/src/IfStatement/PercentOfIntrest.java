package IfStatement;

import java.util.Scanner;

public class PercentOfIntrest {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String gender=sc.next();
		int age=sc.nextInt();
		if(gender.equals("Female")) {
			if(age>=1 && age<=58) {
				System.out.println("8.2%");
			}
			else if(age>58 && age<101) {
				System.out.println("9.2%");
			}else {
				System.out.println("Invalid Age");

			}
		}
		else if(gender.equals("Male")){
			if(age>=1 && age<=58) {
				System.out.println("8.4%");
			}
			else if(age>58 && age<101) {
				System.out.println("10.5%");
			}else {
				System.out.println("Invalid Age");

			}
			
		}else {
			System.out.println("Invalid Gender");
		}
	}

}
