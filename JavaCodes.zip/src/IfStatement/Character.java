package IfStatement;

import java.util.Scanner;

public class Character {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char first=sc.nextLine().charAt(0);
		char second=sc.nextLine().charAt(0);
		if(first<second) {
			System.out.println(first+","+second);
		}else{
			System.out.println(second+","+first);
		 }
		sc.close();
		
	
		
	}

}