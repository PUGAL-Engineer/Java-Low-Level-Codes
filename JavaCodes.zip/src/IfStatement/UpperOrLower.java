package IfStatement;

import java.util.Scanner;

public class UpperOrLower {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char letter=sc.next().charAt(0);
		if(Character.isUpperCase(letter)) {
			System.out.println(Character.toLowerCase(letter));
		}
		else {
			System.out.println(Character.toUpperCase(letter));
		}
	}

}
