package IfStatement;

import java.util.Scanner;

class Numberr{
	 Numberr(int num) {
		if(num%2==0) {
			System.out.println("Even Number");
			
		}else {
			System.out.println("Odd Number");
		}
	}
}

public class OddOrEven {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter The Number: ");
		int num=sc.nextInt();
		 sc.close();
		new Numberr(num);
	   
		
	}

}
