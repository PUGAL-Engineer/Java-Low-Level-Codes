package IfStatement;

import java.util.Scanner;

public class TypeOfChar {
	public static void main(String[] args) {
		
	
	Scanner sc=new Scanner(System.in);
	char le=sc.nextLine().charAt(0);
	if(Character.isAlphebetic(le)) {
		System.out.println("Alphabetic");	
	}else if(Character.isDigit(le)) {
		System.out.println("Digit");	
	}else {
		System.out.println("Special Character");	
	}
}
}